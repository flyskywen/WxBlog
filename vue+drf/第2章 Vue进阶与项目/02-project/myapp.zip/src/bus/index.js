import Vue from 'vue'
var bus = new Vue()

// commonJS moudle.exports
export default bus
