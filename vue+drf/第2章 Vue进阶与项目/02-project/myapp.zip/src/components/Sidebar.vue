<template>
  <aside>
    sidebar
    <ul>
      <li>11111</li>
      <li>11111</li>
      <li>11111</li>
    </ul>
  </aside>
</template>

<style lang="scss" scoped>

ul{
  li{
    background:blue
  }
}
</style>
