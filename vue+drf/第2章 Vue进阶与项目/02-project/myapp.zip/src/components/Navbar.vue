<template>
  <nav>
    navbar-<slot></slot>
  </nav>
</template>

<style lang="scss" scoped>

</style>
