function A1 () {

}

function A2 () {

}

function A3 () {

}
// commonjs 规范
// module.exports =

// ES6导出规范
const All = {
  A1,
  A2,
  A3
}

export default All
