export const HIDE_TABBAR_MUTATION = 'hide'
export const SHOW_TABBAR_MUTATION = 'show'

export const AAAAA = 'A'
